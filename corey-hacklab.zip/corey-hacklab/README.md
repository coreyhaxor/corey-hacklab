# CoreyHackLab 🧨

**Termux Pentest Lab Setup Script**

This is a custom shell script by Corey to set up a pentesting lab environment in Termux on Android.

## 🔧 How to Use

1. Open Termux
2. Download this script:
   ```bash
   curl -O https://raw.githubusercontent.com/coreyhaxor/corey-hacklab/main/coreyhacklab.sh
   ```
3. Give it permission and run:
   ```bash
   chmod +x coreyhacklab.sh
   ./coreyhacklab.sh
   ```

## 🚀 Features

- Installs hacker tools
- Speeds up Termux
- Custom setup tuned for Samsung A15

---

💀 Made for chaos. Stay smart, stay sharp.
